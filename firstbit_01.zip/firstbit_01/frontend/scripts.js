document.addEventListener('DOMContentLoaded', () => {
    showPage('login');

    document.getElementById('loginForm').addEventListener('submit', login);
    document.getElementById('registerForm').addEventListener('submit', register);
});

function showPage(pageId) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
}

async function login(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    const response = await fetch('http://localhost:5000/api/users/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });

    const data = await response.json();
    if (response.ok) {
        localStorage.setItem('token', data.token);
        alert('Login successful');
        showPage('attendance');
    } else {
        alert(data.msg);
    }
}

async function register(event) {
    event.preventDefault();
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    const response = await fetch('http://localhost:5000/api/users/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role: 'student' })
    });

    const data = await response.json();
    if (response.ok) {
        alert('Registration successful');
        showPage('login');
    } else {
        alert(data.msg);
    }
}

async function markAttendance() {
    const token = localStorage.getItem('token');
    if (!token) {
        alert('Please login first');
        showPage('login');
        return;
    }

    const response = await fetch('http://localhost:5000/api/attendance/mark', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: new FormData(document.getElementById('attendanceForm'))
    });

    const data = await response.json();
    if (response.ok) {
        alert('Attendance marked successfully');
    } else {
        alert(data.msg);
    }
}

async function loadAttendanceHistory() {
    const token = localStorage.getItem('token');
document.addEventListener('DOMContentLoaded', () => {
    showPage('login');

    document.getElementById('loginForm').addEventListener('submit', login);
    document.getElementById('registerForm').addEventListener('submit', register);
});

function showPage(pageId) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
}

async function login(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    const response = await fetch('http://localhost:5000/api/users/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });

    const data = await response.json();
    if (response.ok) {
        localStorage.setItem('token', data.token);
        alert('Login successful');
        showPage('attendance');
    } else {
        alert(data.msg);
    }
}

async function register(event) {
    event.preventDefault();
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    const response = await fetch('http://localhost:5000/api/users/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role: 'student' })
    });

    const data = await response.json();
    if (response.ok) {
        alert('Registration successful');
        showPage('login');
    } else {
        alert(data.msg);
    }
}

async function markAttendance() {
    const token = localStorage.getItem('token');
    if (!token) {
        alert('Please login first');
        showPage('login');
        return;
    }

    const response = await fetch('http://localhost:5000/api/attendance/mark', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: new FormData(document.getElementById('attendanceForm'))
    });

    const data = await response.json();
    if (response.ok) {
        alert('Attendance marked successfully');
    } else {
        alert(data.msg);
    }
}

async function loadAttendanceHistory() {
    const token = localStorage.getItem('token')
}
}